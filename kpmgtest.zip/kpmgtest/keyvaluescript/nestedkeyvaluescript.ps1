﻿

$keys='thumbnail/fname'
$keys=$keys.Split('/')



$jsonobject = "{`"name`": `"donut`",`"image`":{`"fname`": `"donut.jpg`",`"w`": 200,`"h`": 200},`"thumbnail`":{`"fname`": `"donutThumb.jpg`",`"w`": 32,`"h`": 32}}"


$object=$jsonObject | ConvertFrom-Json

foreach($key in $keys)
{
 
           
            $object= $object | Select-Object -ExpandProperty $key
                         
 }



Write-Host "value of key is $object"  