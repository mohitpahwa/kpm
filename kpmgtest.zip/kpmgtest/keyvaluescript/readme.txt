Hi Sir,

I have seen multiple peoplle have asked this question and there was result in sites like stackoverflow (example : 
https://stackoverflow.com/questions/46451994/set-value-of-nested-object-property-by-name-in-powershell) but as I wanted to create a custom code so I created a powershell script. Instead of values like ABCD I have tasken JSON data from below URL.


https://www.example-code.com/powershell/json_nested_objects.asp


I have attached screenshot where you can see it's working fine.


