As per my understanding We have to fund metadata of Azure VM.

I created a powershell script where fetching all the vm's in a subscription and expoerted that details in CSV fiule.  We can also get ouput in json form format by simple using convertto json command.
There are other ways also like invoking Rest Api but as I have worked on multiple Azure runbooks and powershell scripts I think this is the best approach

