﻿

$output = @()
$output += "ResourceGroup, Name, Location, VmSize,SKU"
Set-AzContext -Subscription 5d3e7eb8-eb53-409d-b9a9-8101f4a8e798  # set context of your subscription

$vms=Get-AzVM   #fetch all the vm details

foreach ($vm in $vmdetail)  #loop for each vm in that subscription

{
$resourcegroup=$vm.ResourceGroupName
$Name=$vm.Name
$location=$vm.Location
$VmSize=$vm.HardwareProfile.VmSize
$SKU=$vm.StorageProfile.ImageReference.Sku
$output+= ("$resourcegroup, $Name, $location, $VmSize, $SKU")

}

#Return the outputArray
$Output | ConvertFrom-csv | Export-csv -Path D:/vmdetails.csv -NoTypeInformation  #will create csv with vm details


#in case you want output in json simply write  $output | ConvertTo-Json