Hi Sir just to let you know I have not copied a single line of code from anywhere and tried to use orignal custom code as per my understanding .


Also for the sake of time not used parameters and variables so it's naming convention is mostly hardcoded but have given example that how we can use variable and parameteres.
Tools Used : Visual studio code

Extension used: Azure ARM extension.

Below are the activities done in this ARM Template.

1.)created 2 window VM's as well as availabillity set and these VM's are part of it)

2.) Created external Load balancer and Added frontend servers in the backend pool
3.)Created LInux VM and added in availabillity set
4.) Created Backend Load Balancer
5.)Created SQL Databases(retention policy, backup etc not covered)
   

Attached is the diagram to understand the flow.

Also created powershell script to deploy this Template using powershell New-AzureRmResourceGroupDeployment command





