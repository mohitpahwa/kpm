﻿
$templaate=D:\kpmg.json

$resourceDeploymentName='mohitdeployment'
$resourceGroupName='mohitrg'

New-AzureRmResourceGroupDeployment `
    -Name 
     `
    -ResourceGroupName $resourceGroupName `
    -TemplateFile $template ``
    -Verbose -Force